
import Website from './Website.jsx'
export default function App() { return <Website /> }
